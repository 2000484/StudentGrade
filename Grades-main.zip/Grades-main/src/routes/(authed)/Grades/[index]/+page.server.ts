export const prerender = 'auto';
